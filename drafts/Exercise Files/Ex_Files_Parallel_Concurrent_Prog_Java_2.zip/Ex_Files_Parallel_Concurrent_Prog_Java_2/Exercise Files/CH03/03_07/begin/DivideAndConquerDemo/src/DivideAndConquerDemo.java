/**
 * Recursively sum a range of numbers
 */

public class DivideAndConquerDemo {
    public static void main(String args[]) {

    }
}