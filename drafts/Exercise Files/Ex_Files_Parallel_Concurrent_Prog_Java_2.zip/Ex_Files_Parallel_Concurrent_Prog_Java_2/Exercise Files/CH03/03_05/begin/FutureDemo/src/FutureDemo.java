/**
 * Check how many vegetables are in the pantry
 */

public class FutureDemo {
    public static void main(String args[]) {

    }
}