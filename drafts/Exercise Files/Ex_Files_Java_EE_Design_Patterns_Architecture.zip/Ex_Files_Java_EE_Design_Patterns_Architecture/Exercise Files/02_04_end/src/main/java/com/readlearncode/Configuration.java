package com.readlearncode;

import javax.ejb.Startup;
import javax.inject.Singleton;

/**
 * Source code github.com/readlearncode
 *
 * @author Alex Theedom www.readlearncode.com
 * @version 1.0
 */
@Startup
@Singleton
public class Configuration {
}