package com.readlearncode;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * @author Alex Theedom www.readlearncode.com
 * @version 1.0
 */
@ApplicationPath("/api")
public class RESTConfig extends Application {}