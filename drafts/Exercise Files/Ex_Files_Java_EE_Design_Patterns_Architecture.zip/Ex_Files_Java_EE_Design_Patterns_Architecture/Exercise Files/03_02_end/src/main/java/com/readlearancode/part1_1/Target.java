package com.readlearancode.part1_1;

import javax.inject.Inject;

/**
 * Source code github.com/readlearncode
 *
 * @author Alex Theedom www.readlearncode.com
 * @version 1.0
 */
public class Target {

    @Inject
    Subject subject;

}